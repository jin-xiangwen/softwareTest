package com.tongji.softwaretest.shikebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShikeBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
