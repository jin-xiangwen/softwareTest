package com.tongji.softwaretest.shikebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShikeBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShikeBackendApplication.class, args);
    }

}
