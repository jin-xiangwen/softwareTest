import UIKit

class CollectionViewCell: UICollectionViewCell {

  
    @IBOutlet weak var activityLabel: UILabel!
    @IBOutlet weak var activityDetailLabel: UILabel!
    @IBOutlet weak var activityImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
