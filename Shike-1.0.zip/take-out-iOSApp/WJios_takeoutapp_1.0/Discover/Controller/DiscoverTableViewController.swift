import UIKit

private let identifier = "tableviewCell"

class DiscoverTableViewController: UITableViewController {
    
    //MARK:- 懒加载
    private lazy var headerView: DiscoverHeaderView = {
        let rect = CGRect(x: 0, y: 0, width: kScreenW, height: 160 + 120 + 10)
        let headerView = DiscoverHeaderView(frame: rect)
        headerView.delegate = self
        return headerView
    }()
    
    
    //MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //设置UI
        setupUI()
        
        //注册tableviewcell
        let nib = UINib(nibName: "DiscoverTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: identifier)
//        tableView.register(DiscoverTableViewCell.self, forCellReuseIdentifier: identifier)
  }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 10
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier)
        return cell!
        
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 188
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("点击了：\(indexPath)")
        let storeVc = UIStoryboard(name: "Store", bundle: nil).instantiateInitialViewController()!
        //let storeVc = StoreViewController()
        self.navigationController?.pushViewController(storeVc, animated: true)
    }

}

//MARK:- 设置UI
extension DiscoverTableViewController{
    
    private func setupUI(){
        //1. 添加headerview
        self.tableView.tableHeaderView = headerView
    }
    
}

//MARK:- 遵守headview的delegate
extension DiscoverTableViewController: DiscoverCollectionViewDelegate{
    func ClickItem(DiscoverView: DiscoverHeaderView, Index: Int) {
        print(Index)
        //弹出控制器
        switch Index {
        case 0:
            let vc = CreditsViewController()
            self.navigationItem.backBarButtonItem?.title = "积分兑换"
            self.navigationController?.pushViewController(vc, animated: true)
        case 1:
            let vc = UIStoryboard(name: "Invitation", bundle: nil).instantiateInitialViewController() as! InvitationViewController
            self.navigationItem.backBarButtonItem?.title = "推荐有奖"
            self.navigationController?.pushViewController(vc, animated: true)
        case 3:
            let vc = PayViewController()
            self.navigationItem.backBarButtonItem?.title = "生活缴费"
            self.navigationController?.pushViewController(vc, animated: true)
        case 2:
            let vc = GroupPurchaseViewController()
            self.navigationItem.backBarButtonItem?.title = "团购"
            self.navigationController?.pushViewController(vc, animated: true)
        default:
            print("还没完成")
        }
    }
    
    
}












