import Foundation

extension NSDate{
    class func getCurrentTime() -> Int {
        let nowDate = NSDate()
        let interval = Int(nowDate.timeIntervalSince1970)
        return interval
    }
}




