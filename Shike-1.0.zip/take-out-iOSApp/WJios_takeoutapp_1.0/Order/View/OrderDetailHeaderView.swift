import UIKit

protocol OrderDetailHeaderDelegate : class {
    func ClickTheButton(headerView: OrderDetailHeaderView)
    func ClickCommentButton(headerView: OrderDetailHeaderView)
}

class OrderDetailHeaderView: UICollectionReusableView {
    
    
    weak var delegate : OrderDetailHeaderDelegate?

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func CommentButton(_ sender: Any) {
        //通知代理
        delegate?.ClickCommentButton(headerView: self)
    }
    @IBAction func AgainButton(_ sender: Any) {
        //通知代理
        delegate?.ClickTheButton(headerView: self)
    }
}

