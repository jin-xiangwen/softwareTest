import UIKit

class UserViewModel: NSObject {

    var userModel = UserModel()
    
    override init() {
        
    }
    
    //提交数据
    func submitData(dict : [String : NSObject],finishedCallback : @escaping (_ flag : Bool) -> ()){
        NetworkTools.submitData(type: .POST, URLString: "http://121.5.219.239:9090/adduser", parameters: dict) { (result) in
            
            guard let resultDict = result as? [String : NSObject] else {return}
            let flag : Bool = (resultDict["success"] != nil)
            print("数据提交完毕")
            finishedCallback(flag)
        }
        
    }
    
    //请求数据
    func requestData(userId : Int, finishedCallback : @escaping () ->()){
        print("开始请求数据")
        NetworkTools.requestData(type: .GET, URLString: "http://121.5.219.239:9090/getuser", parameters: ["userId" : "\(userId)"]) { (result) in
            guard let resultDict = result as? [String : NSObject] else {return}
            guard let data = resultDict["user"] as? [String : NSObject] else {return}
            self.userModel = UserModel(dict: data)
            print("用户数据请求完毕")
            finishedCallback()
        }
        
    }
}
