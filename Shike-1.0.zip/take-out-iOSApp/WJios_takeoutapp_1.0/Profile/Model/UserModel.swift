import UIKit

class UserModel: NSObject {

    @objc var userId : Int = 0
    @objc var userName : String = ""
    @objc var userPassword : String = ""
    @objc var userTel : String = ""
    @objc var userImage : String = ""
    
    init(dict: [String : NSObject]){
        super.init()
        setValuesForKeys(dict)
    }
    
    override init() {
        
    }
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
}
