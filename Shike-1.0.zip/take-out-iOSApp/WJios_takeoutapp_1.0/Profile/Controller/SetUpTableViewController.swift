import UIKit

class SetUpTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(indexPath.section == 0){
            if USERID != 0{
                let story = UIStoryboard(name: "User", bundle: nil)
                let vc = story.instantiateInitialViewController() as! UserTableViewController
                self.navigationItem.backBarButtonItem?.title = "账户与安全"
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else{
                let vc = UIStoryboard(name: "Logon", bundle: nil).instantiateInitialViewController() as! LogonViewController
                self.navigationItem.backBarButtonItem?.title = "账户与安全"
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}
