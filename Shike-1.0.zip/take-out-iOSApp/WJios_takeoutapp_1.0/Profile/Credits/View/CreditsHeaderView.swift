import UIKit

class CreditsHeaderView: UICollectionReusableView {

    @IBOutlet weak var creditsLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
