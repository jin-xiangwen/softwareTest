import UIKit

class MainViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
//        addChildVC(storyname: "Home")
//        addChildVC(storyname: "Discover")
//        addChildVC(storyname: "Order")
//        addChildVC(storyname: "Profile")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
////在tabbar中添加自控制器
//    private func addChildVC(storyname: String){
//        let childvc = UIStoryboard(name: storyname, bundle: nil).instantiateInitialViewController()!
//        addChildViewController(childvc)
//    }
//
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
